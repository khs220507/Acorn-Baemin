package com.acorn.baemin.user.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.acorn.baemin.domain.UserDTO;
import com.acorn.baemin.login.repository.LoginRepositoryI;
import com.acorn.baemin.user.repository.UserRepositoryI;

public class UserService {
//	@Autowired
//	private UserRepositoryI userRepositoryi;
//
//	public UserDTO signup(String userId, String userPw, String userName, String userNickName, String userPhone, String userEmail, String userBirth, String userGender, String userPostCode, String userAddress, String userAddressDetail ) {
//		try {
//			return userRepositoryi.signup(userId, userPw, userName, userNickName, userPhone, userEmail, userBirth, userGender, userPostCode, userAddress, userAddressDetail);
//		} catch (Exception e) {
//			e.printStackTrace();
//			return null;
//		}
//	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
