package com.acorn.baemin.user.repository;

public class base {

}
