package com.acorn.baemin.selectstrore.repository;

public class base {

}
