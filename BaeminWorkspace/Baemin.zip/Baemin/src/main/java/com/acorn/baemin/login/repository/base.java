package com.acorn.baemin.login.repository;

public class base {

}
