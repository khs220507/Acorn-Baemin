package com.acorn.baemin.seller.repository;

public class base {

}
