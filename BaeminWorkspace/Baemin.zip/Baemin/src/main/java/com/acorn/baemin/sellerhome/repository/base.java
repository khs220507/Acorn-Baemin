package com.acorn.baemin.sellerhome.repository;

public class base {

}
