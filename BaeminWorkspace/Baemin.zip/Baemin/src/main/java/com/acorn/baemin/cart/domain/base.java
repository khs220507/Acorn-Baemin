package com.acorn.baemin.cart.domain;

public class base {
	public static void main(String[] args) {
		System.out.println("jenkins test");
	}

}
