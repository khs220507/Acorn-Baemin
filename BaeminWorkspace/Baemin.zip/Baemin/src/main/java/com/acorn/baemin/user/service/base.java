package com.acorn.baemin.user.service;

public class base {

}
